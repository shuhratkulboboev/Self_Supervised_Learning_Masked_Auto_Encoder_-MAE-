cfg = dict(
    model='wavevit_b',
    drop_path=0.1,
    clip_grad=None,
    output_dir='checkpoints/wavevit_b',
)