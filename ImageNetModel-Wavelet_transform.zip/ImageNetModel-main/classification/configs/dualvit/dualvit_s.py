cfg = dict(
    model='dualvit_s',
    drop_path=0.15,
    clip_grad=None,
    output_dir='checkpoints/dualvit_s',
)