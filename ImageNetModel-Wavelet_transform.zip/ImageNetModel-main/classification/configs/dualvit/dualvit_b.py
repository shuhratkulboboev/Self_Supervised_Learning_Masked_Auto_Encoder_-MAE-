cfg = dict(
    model='dualvit_b',
    drop_path=0.15,
    clip_grad=None,
    output_dir='checkpoints/dualvit_b',
)